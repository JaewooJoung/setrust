#!/bin/bash
# install.sh - WASM 프로젝트 템플릿 설치 스크립트
# Arch Linux용

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$HOME/.local/bin"
TEMPLATE_DIR="$HOME/SW/rust/wasmtemp"

echo "🦀 nwasm 설치 중..."
echo ""

# 1. 필요한 패키지 확인
echo "[1/4] 필요한 패키지 확인..."
MISSING=""
command -v rustc &>/dev/null || MISSING="$MISSING rust"
command -v wasm-pack &>/dev/null || MISSING="$MISSING wasm-pack"
command -v cargo &>/dev/null || MISSING="$MISSING cargo"

if [[ -n "$MISSING" ]]; then
    echo ""
    echo "⚠️  다음 패키지가 필요합니다:"
    echo "   sudo pacman -S$MISSING"
    echo ""
    echo "   wasm-pack 설치:"
    echo "   cargo install wasm-pack"
    echo ""
fi

# 2. 디렉토리 생성
echo "[2/4] 디렉토리 생성..."
mkdir -p "$INSTALL_DIR"
mkdir -p "$TEMPLATE_DIR/src"
mkdir -p "$TEMPLATE_DIR/.vscode"

# 3. 파일 복사
echo "[3/4] 파일 복사..."
cp "$SCRIPT_DIR/nwasm" "$INSTALL_DIR/nwasm"
chmod +x "$INSTALL_DIR/nwasm"

cp "$SCRIPT_DIR/templates/Cargo.toml.template" "$TEMPLATE_DIR/"
cp "$SCRIPT_DIR/templates/index.html.template" "$TEMPLATE_DIR/"
cp "$SCRIPT_DIR/templates/build.sh.template" "$TEMPLATE_DIR/"
cp "$SCRIPT_DIR/templates/serve.sh.template" "$TEMPLATE_DIR/"
cp "$SCRIPT_DIR/templates/runall.sh.template" "$TEMPLATE_DIR/"
cp "$SCRIPT_DIR/templates/README.md.template" "$TEMPLATE_DIR/"
cp "$SCRIPT_DIR/templates/src/lib.rs.template" "$TEMPLATE_DIR/src/"
cp "$SCRIPT_DIR/templates/.vscode/tasks.json.template" "$TEMPLATE_DIR/.vscode/"

# 4. PATH 확인
echo "[4/4] 설정 확인..."
if [[ ":$PATH:" != *":$INSTALL_DIR:"* ]]; then
    echo ""
    echo "⚠️  ~/.bashrc에 다음을 추가하세요:"
    echo ""
    echo '    export PATH="$HOME/.local/bin:$PATH"'
    echo ""
fi

# bashrc 설정 출력
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ 설치 완료!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📁 설치 위치:"
echo "   스크립트: $INSTALL_DIR/nwasm"
echo "   템플릿:   $TEMPLATE_DIR/"
echo ""
echo "📝 ~/.bashrc에 추가할 내용:"
echo ""
cat << 'BASHRC'
# WASM Development
export PATH="$HOME/.local/bin:$PATH"
export NGINX_WASM_DIR="/srv/http/wasm-test"
BASHRC
echo ""
echo "🚀 사용법:"
echo "   nwasm my-project    # 새 프로젝트 생성"
echo "   cd ~/SW/rust/my-project"
echo "   ./runall.sh         # 빌드 + 배포 + 브라우저"
echo ""
