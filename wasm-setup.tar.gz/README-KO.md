# nwasm - Rust WASM 프로젝트 생성기

Arch Linux에서 Rust WASM 프로젝트를 쉽게 만들 수 있는 도구입니다.

## 📦 설치 방법

### 1. 필수 패키지 설치 (Arch Linux)

```bash
# Rust 설치
sudo pacman -S rust

# wasm-pack 설치
cargo install wasm-pack

# nginx 설치 (선택사항 - 로컬 서버 대신 사용)
sudo pacman -S nginx
```

### 2. nginx 설정 (처음 한 번만)

```bash
# wasm 폴더 생성
sudo mkdir -p /srv/http/wasm-test
sudo chown -R $USER:$USER /srv/http/wasm-test

# nginx 시작
sudo systemctl start nginx
sudo systemctl enable nginx
```

### 3. nwasm 설치

```bash
# 압축 해제
tar -xzf wasm-setup.tar.gz
cd wasm-setup

# 설치
chmod +x install.sh
./install.sh
```

### 4. bashrc 설정

`~/.bashrc` 파일 끝에 추가:

```bash
# WASM Development
export PATH="$HOME/.local/bin:$PATH"
export NGINX_WASM_DIR="/srv/http/wasm-test"
```

설정 적용:
```bash
source ~/.bashrc
```

---

## 🚀 사용법

### 새 프로젝트 만들기

```bash
nwasm my-project
```

이 명령어는:
1. `~/SW/rust/my-project` 폴더 생성
2. Rust WASM 템플릿 적용
3. VS Code 자동 실행

### 프로젝트 실행

```bash
cd ~/SW/rust/my-project
./runall.sh
```

이 명령어는:
1. WASM 빌드
2. nginx에 배포
3. 브라우저 자동 실행

끝! 브라우저에서 바로 확인할 수 있습니다.

---

## 📁 파일 구조

```
~/SW/rust/
├── wasmtemp/              # 템플릿 폴더
│   ├── Cargo.toml.template
│   ├── index.html.template
│   ├── build.sh.template
│   ├── serve.sh.template
│   ├── runall.sh.template
│   ├── README.md.template
│   ├── src/
│   │   └── lib.rs.template
│   └── .vscode/
│       └── tasks.json.template
│
└── my-project/            # 생성된 프로젝트
    ├── Cargo.toml
    ├── index.html
    ├── src/lib.rs
    ├── build.sh
    ├── serve.sh
    ├── runall.sh
    └── pkg/               # 빌드 결과물
```

---

## 🔧 명령어 설명

| 명령어 | 설명 |
|--------|------|
| `nwasm 프로젝트명` | 새 프로젝트 생성 |
| `./build.sh` | WASM 빌드 (release) |
| `./build.sh dev` | WASM 빌드 (debug, 빠름) |
| `./serve.sh` | 로컬 서버 실행 (nginx 없이) |
| `./runall.sh` | **빌드 + 배포 + 브라우저** (추천) |

---

## 🌐 접속 주소

- **nginx 사용시**: http://localhost/wasm-test/프로젝트명/
- **로컬 서버**: http://localhost:8080/

---

## ❓ 문제 해결

### "wasm-pack: command not found"
```bash
cargo install wasm-pack
source ~/.bashrc
```

### "Permission denied" (nginx 폴더)
```bash
sudo chown -R $USER:$USER /srv/http/wasm-test
```

### 브라우저가 안 열림
```bash
# chromium 설치
sudo pacman -S chromium

# 또는 수동으로 열기
chromium http://localhost/wasm-test/my-project/
```

### 포트 8080 사용 중
```bash
# 사용 중인 프로세스 확인
lsof -i :8080

# 종료
fuser -k 8080/tcp
```

---

## 📝 예제 코드 설명

생성된 프로젝트에는 다음 기능이 포함되어 있습니다:

### Rust 함수 (src/lib.rs)

```rust
// 문자열 처리
greet(name)           // 인사말 반환
reverse_string(s)     // 문자열 뒤집기
to_uppercase(s)       // 대문자 변환
count_chars(s)        // 글자 수 세기

// 수학 연산
add(a, b)             // 덧셈
multiply(a, b)        // 곱셈
factorial(n)          // 팩토리얼
fibonacci(n)          // 피보나치
is_prime(n)           // 소수 판별

// 배열 처리
sum_array(arr)        // 배열 합계
sort_numbers(arr)     // 배열 정렬
compute_primes(n)     // n까지 소수 찾기

// DOM 조작
update_element_from_rust(id, content)  // HTML 요소 업데이트
```

### JavaScript에서 호출

```javascript
import init, * as wasm from './pkg/my-project.js';

await init();

wasm.greet("World");        // "Hello, World! 👋"
wasm.add(2, 3);             // 5
wasm.is_prime(97);          // true
```

---

## 🎯 VS Code 단축키

프로젝트를 열면 `Ctrl+Shift+B`로 빌드 작업을 실행할 수 있습니다:
- **Run All** - 빌드 + 배포 + 브라우저 (기본)
- Build (Release)
- Build (Debug)
- Local Server
